import logging
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from config import get_settings

logger = logging.getLogger(__name__)

_db_instance = None

def initialize_db():
    global _db_instance
    settings = get_settings()
    try:
        client = MongoClient(settings.mongodb_url)
        client.admin.command('ping')
        _db_instance = client[settings.DB_NAME]
        
        _db_instance[settings.DOCUMENTS_COLLECTION].create_index("upload_timestamp")
        _db_instance[settings.DOCUMENTS_COLLECTION].create_index("domain")
        _db_instance[settings.EMBEDDINGS_COLLECTION].create_index("document_id")
        
        logger.info("Database initialized successfully")
    except ConnectionFailure as e:
        logger.error(f"Failed to connect to MongoDB: {e}")
        raise

def get_db():
    if _db_instance is None:
        initialize_db()
    return _db_instance

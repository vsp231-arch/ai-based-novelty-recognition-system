import os
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    mongodb_url: str = os.getenv("MONGODB_URL", "mongodb://localhost:27017/novelty_research")
    fastapi_env: str = os.getenv("FASTAPI_ENV", "development")
    model_name: str = os.getenv("MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2")
    max_pdf_size: int = int(os.getenv("MAX_PDF_SIZE", 50))
    similarity_threshold: float = float(os.getenv("SIMILARITY_THRESHOLD", 0.85))
    chunk_size: int = int(os.getenv("CHUNK_SIZE", 512))
    batch_size: int = int(os.getenv("BATCH_SIZE", 32))
    api_port: int = int(os.getenv("API_PORT", 8000))
    frontend_url: str = os.getenv("FRONTEND_URL", "http://localhost:5173")

    DB_NAME = "novelty_research"
    DOCUMENTS_COLLECTION = "documents"
    EMBEDDINGS_COLLECTION = "embeddings"
    INITIAL_DATA_COLLECTION = "initial_abstracts"

    class Config:
        env_file = ".env"

@lru_cache()
def get_settings():
    return Settings()

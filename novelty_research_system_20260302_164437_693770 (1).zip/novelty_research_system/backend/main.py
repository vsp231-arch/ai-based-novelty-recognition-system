import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import logging

from config import get_settings
from database import initialize_db, get_db
from ml_service import initialize_ml_service
from routes import analyze_router, documents_router, stats_router

load_dotenv()
logger = logging.getLogger(__name__)

app = FastAPI(
    title="AI Novelty & Research Intelligence System",
    version="1.0.0",
    description="Advanced research novelty detection and plagiarism analysis"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    logger.info("Starting up application...")
    initialize_ml_service()
    initialize_db()
    logger.info("ML model and database initialized")

@app.get("/health")
async def health_check():
    return {"status": "ready"}

app.include_router(analyze_router.router, prefix="/api", tags=["analysis"])
app.include_router(documents_router.router, prefix="/api", tags=["documents"])
app.include_router(stats_router.router, prefix="/api", tags=["statistics"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

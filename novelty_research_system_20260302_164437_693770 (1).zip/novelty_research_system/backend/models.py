from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from enum import Enum

class ClassificationEnum(str, Enum):
    NOVEL = "Novel"
    MODERATE = "Moderate"
    LOW_NOVELTY = "Low Novelty"

class ResearchInput(BaseModel):
    text: str
    title: Optional[str] = None
    domain: Optional[str] = None

class Document(BaseModel):
    id: str
    title: str
    abstract: str
    domain: str
    full_text: str
    upload_timestamp: datetime
    source: str

class Embedding(BaseModel):
    document_id: str
    embedding_vector: List[float]
    text_chunk: str
    chunk_index: int

class SimilarDocument(BaseModel):
    id: str
    title: str
    similarity_score: float
    domain: str

class PlagiarismChunk(BaseModel):
    chunk_text: str
    similar_document_id: str
    similarity_score: float
    overlap_percentage: float

class AnalysisResult(BaseModel):
    novelty_score: float
    plagiarism_score: float
    classification: ClassificationEnum
    similar_documents: List[SimilarDocument]
    plagiarism_chunks: List[PlagiarismChunk]
    explanation: str
    processing_time: float

class PDFUploadResponse(BaseModel):
    document_id: str
    title: str
    abstract: str
    analysis_result: AnalysisResult

class SystemStats(BaseModel):
    total_documents: int
    total_embeddings: int
    average_novelty_score: float
    domain_distribution: dict
    processing_time_avg: float

class DomainStat(BaseModel):
    domain: str
    document_count: int
    avg_novelty: float
    keywords: List[str]

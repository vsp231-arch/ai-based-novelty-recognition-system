import logging
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from config import get_settings

logger = logging.getLogger(__name__)

_model_instance = None

def load_model():
    global _model_instance
    settings = get_settings()
    logger.info(f"Loading model: {settings.model_name}")
    _model_instance = SentenceTransformer(settings.model_name)
    logger.info("Model loaded successfully")

def get_model():
    if _model_instance is None:
        load_model()
    return _model_instance

def generate_embeddings(texts):
    model = get_model()
    embeddings = model.encode(texts, convert_to_numpy=True)
    return embeddings.tolist() if isinstance(embeddings, np.ndarray) else embeddings

def compute_similarity(embedding1, embedding2):
    e1 = np.array(embedding1).reshape(1, -1)
    e2 = np.array(embedding2).reshape(1, -1)
    similarity = cosine_similarity(e1, e2)
    return float(similarity[0][0])

# System Architecture

## Overview

```
┌─────────────────┐
│  React Frontend │
└────────┬────────┘
         │ HTTP/REST
         ↓
┌──────────────────┐
│  FastAPI Backend │
├──────────────────┤
│  Routes          │
│  Services        │
│  Utilities       │
└────────┬────────┘
         │
    ┌────┴─────┐
    ↓          ↓
┌─────────┐  ┌──────────────────┐
│ MongoDB │  │ SentenceTransform │
│         │  │ (ML Model)        │
└─────────┘  └──────────────────┘
```

## Component Architecture

### Frontend Components
- **Pages**: Dashboard, Analyze, Upload, Documents, Statistics
- **Components**: Layout, Forms, Charts, Cards, Modals
- **Utils**: API client, validation, formatting
- **Hooks**: Custom React hooks for state management
- **Context**: Global app state

### Backend Structure
- **Routes**: API endpoints organized by feature
- **Services**: Business logic (ML, analysis)
- **Utils**: Helper functions (PDF, similarity, summarization)
- **Database**: MongoDB connection and queries
- **Models**: Pydantic data models

## Data Flow

1. User uploads PDF/text
2. Backend receives and validates input
3. Text extraction (PDF) and chunking
4. Embedding generation via SentenceTransformers
5. Similarity computation against stored embeddings
6. Novelty score calculation (1 - max_similarity) * 100
7. Plagiarism detection on high-similarity chunks
8. Classification (Novel/Moderate/Low)
9. Results returned to frontend
10. Document stored in MongoDB for future comparisons

## Database Schema

### Documents Collection
```
{
  "_id": ObjectId,
  "id": "uuid",
  "title": "Research Title",
  "abstract": "Summary...",
  "domain": "computer-science",
  "full_text": "Complete text...",
  "upload_timestamp": ISODate,
  "source": "uploaded|initial"
}
```

### Embeddings Collection
```
{
  "_id": ObjectId,
  "document_id": "uuid",
  "embedding_vector": [float...], // 384 dimensions
  "text_chunk": "Text chunk...",
  "chunk_index": 0
}
```

## Performance Optimization

- **Model Caching**: Load model once at startup
- **Batch Processing**: Process embeddings in batches
- **Async I/O**: Non-blocking file operations
- **Database Indexing**: Indexes on frequently queried fields
- **In-Memory Cache**: Store frequently accessed data

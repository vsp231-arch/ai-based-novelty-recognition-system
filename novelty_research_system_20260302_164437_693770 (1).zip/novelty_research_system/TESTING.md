# Testing Guide

## Backend Tests

### Unit Tests
```bash
cd backend
pytest tests/test_analysis.py
pytest tests/test_db.py
pytest tests/test_pdf_processing.py
```

### Test Coverage
```bash
pytest --cov=. --cov-report=html
```

### Run All Tests
```bash
pytest
```

## Frontend Tests

```bash
cd frontend
npm test
```

## Integration Tests

```bash
cd backend
pytest tests/test_frontend_integration.py
```

## API Testing with curl

### Analyze Text
```bash
curl -X POST http://localhost:8000/api/analyze-text \
  -H "Content-Type: application/json" \
  -d '{"text":"Your research text here"}'
```

### Upload PDF
```bash
curl -X POST http://localhost:8000/api/analyze-pdf \
  -F "file=@sample.pdf"
```

### Get Documents
```bash
curl http://localhost:8000/api/documents
```

### Get Statistics
```bash
curl http://localhost:8000/api/stats
```

## Test Coverage Goals
- Backend: Aim for 80%+ coverage
- Frontend: Aim for 70%+ coverage
- Critical paths: 100% coverage

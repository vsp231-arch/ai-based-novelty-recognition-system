import os
import json
import sys
from pathlib import Path
from pymongo import MongoClient
from sentence_transformers import SentenceTransformer

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import get_settings

def load_initial_data():
    settings = get_settings()
    
    client = MongoClient(settings.mongodb_url)
    db = client[settings.DB_NAME]
    
    model = SentenceTransformer(settings.model_name)
    
    seed_file = Path(__file__).parent.parent / "seed_data" / "initial_abstracts.json"
    
    with open(seed_file) as f:
        abstracts = json.load(f)
    
    for abstract in abstracts:
        embedding = model.encode(abstract['abstract']).tolist()
        
        db[settings.DOCUMENTS_COLLECTION].insert_one({
            'id': abstract['id'],
            'title': abstract['title'],
            'abstract': abstract['abstract'],
            'domain': abstract['domain'],
            'full_text': abstract['abstract'],
            'source': abstract['source'],
            'upload_timestamp': None
        })
        
        db[settings.EMBEDDINGS_COLLECTION].insert_one({
            'document_id': abstract['id'],
            'embedding_vector': embedding,
            'text_chunk': abstract['abstract'],
            'chunk_index': 0
        })
    
    print(f"Loaded {len(abstracts)} abstracts")

if __name__ == "__main__":
    load_initial_data()

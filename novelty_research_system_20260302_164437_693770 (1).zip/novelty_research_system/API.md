# API Documentation

## Base URL
```
http://localhost:8000/api
```

## Endpoints

### Analysis Endpoints

#### Analyze Text
**POST** `/analyze-text`

Request:
```json
{
  "text": "Your research abstract here...",
  "title": "Research Title (optional)",
  "domain": "computer-science (optional)"
}
```

Response:
```json
{
  "novelty_score": 75.5,
  "plagiarism_score": 12.3,
  "classification": "Novel",
  "similar_documents": [
    {
      "id": "doc_123",
      "title": "Similar Research",
      "similarity_score": 0.65,
      "domain": "computer-science"
    }
  ],
  "plagiarism_chunks": [],
  "explanation": "Your research has high novelty...",
  "processing_time": 2.34
}
```

#### Upload PDF
**POST** `/analyze-pdf`

Request: `multipart/form-data`
- `file`: PDF file

Response: Same as analyze-text

### Document Endpoints

#### List Documents
**GET** `/documents?limit=10&offset=0&domain=computer-science`

Response:
```json
{
  "documents": [...],
  "total_count": 200,
  "processing_time": 0.1
}
```

#### Get Document
**GET** `/documents/{document_id}`

#### Delete Document
**DELETE** `/documents/{document_id}`

#### Search Documents
**GET** `/documents/search?q=machine learning`

### Statistics Endpoints

#### System Stats
**GET** `/stats`

Response:
```json
{
  "total_documents": 250,
  "total_embeddings": 1200,
  "average_novelty_score": 65.4,
  "domain_distribution": {...},
  "processing_time_avg": 2.1
}
```

#### Domain Stats
**GET** `/stats/domains`

#### Trends
**GET** `/stats/trends?days=30`

### Health
**GET** `/health`

Response:
```json
{
  "status": "ready"
}
```

## Error Responses

```json
{
  "error": "Error message",
  "code": 400,
  "details": "Additional details"
}
```

Common status codes:
- `200` - Success
- `400` - Bad request
- `404` - Not found
- `422` - Validation error
- `500` - Server error

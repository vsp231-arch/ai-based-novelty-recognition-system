# AI-Based Novelty & Research Intelligence System

## Overview
An intelligent system that analyzes research ideas and uploaded PDFs to compute novelty scores, plagiarism detection, and semantic similarity analysis.

## Features
- **Research Analysis**: Analyze text inputs or PDF documents
- **Novelty Detection**: Compute novelty scores (0-100%)
- **Plagiarism Detection**: Identify similar/plagiarized content
- **Knowledge Base**: Growing database of research documents
- **Domain Clustering**: Organize documents by research domain
- **Statistics Dashboard**: Real-time analytics and trends

## Architecture
```
Frontend (React) ← API → Backend (FastAPI) ← → MongoDB
                                    ↓
                        SentenceTransformers (ML)
```

## Prerequisites
- Python 3.9+
- Node.js 18+
- MongoDB (local or Docker)
- Docker & Docker Compose (optional)

## Installation

### Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Frontend Setup
```bash
cd frontend
npm install
```

### Configuration
Copy `.env.example` to `.env` and update values:
```bash
cp .env.example .env
```

## Running the Application

### Development Mode

**Terminal 1 - Backend:**
```bash
cd backend
source venv/bin/activate
uvicorn main:app --reload --port 8000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

**Terminal 3 - MongoDB (if not running):**
```bash
docker run -d -p 27017:27017 --name mongodb mongo:latest
```

### Using Docker Compose
```bash
docker-compose up
```

Access the application at `http://localhost:5173`

## API Endpoints

### Analysis
- `POST /analyze-text` - Analyze research idea text
- `POST /analyze-pdf` - Upload and analyze PDF

### Documents
- `GET /documents` - List all documents
- `GET /documents/{id}` - Get document details
- `DELETE /documents/{id}` - Delete document

### Statistics
- `GET /stats` - System statistics
- `GET /stats/domains` - Domain clustering
- `GET /stats/trends` - Temporal trends

### Health
- `GET /health` - System health check

## Database Initialization

Load initial research abstracts:
```bash
cd backend
python scripts/load_initial_data.py
```

## Testing

```bash
cd backend
pytest
pytest --cov=.

cd frontend
npm test
```

## Project Structure

```
novelty_research_system/
├── backend/
│   ├── main.py
│   ├── config.py
│   ├── models.py
│   ├── database.py
│   ├── ml_service.py
│   ├── routes/
│   ├── utils/
│   ├── requirements.txt
│   ├── scripts/
│   └── tests/
├── frontend/
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── pages/
│   │   ├── components/
│   │   ├── utils/
│   │   ├── hooks/
│   │   ├── context/
│   │   └── styles/
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
├── seed_data/
│   └── initial_abstracts.json
├── docker-compose.yml
└── README.md
```

## Key Technologies

**Backend:**
- FastAPI - Async web framework
- MongoDB - NoSQL database
- SentenceTransformers - ML embeddings
- PyMuPDF/PyPDF2 - PDF processing
- Scikit-learn - Similarity computation

**Frontend:**
- React 18 - UI framework
- Vite - Build tool
- Tailwind CSS - Styling
- Recharts - Data visualization
- Axios - HTTP client

## Deployment

See `DEPLOYMENT.md` for production deployment guide.

## Documentation

- `API.md` - API endpoint reference
- `ARCHITECTURE.md` - System design details
- `TESTING.md` - Testing guide
- `DEPLOYMENT.md` - Deployment guide

## Contributing

1. Create a feature branch
2. Make changes
3. Run tests
4. Submit pull request

## License

MIT License

# Deployment Guide

## Local Development

### Prerequisites
- Python 3.9+
- Node.js 18+
- MongoDB local or Docker

### Setup

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Frontend
cd frontend
npm install
```

### Running

```bash
# Terminal 1 - Backend
cd backend
source venv/bin/activate
uvicorn main:app --reload

# Terminal 2 - Frontend
cd frontend
npm run dev

# Terminal 3 - MongoDB
docker run -d -p 27017:27017 mongo:latest
```

## Docker Deployment

```bash
docker-compose up -d
```

## Production Deployment

### Environment Setup

Create `.env` with production values:
```
MONGODB_URL=mongodb+srv://user:pass@cluster.mongodb.net/novelty_research
FASTAPI_ENV=production
MODEL_NAME=sentence-transformers/all-MiniLM-L6-v2
```

### Build and Run

```bash
docker-compose -f docker-compose.yml up -d
```

### Monitoring

- Check logs: `docker logs <container_id>`
- Health check: `curl http://localhost:8000/api/health`
- MongoDB connection: Verify in logs

## Scaling Considerations

Current design supports:
- Up to 100k documents
- Single-instance deployment
- In-memory model caching
- MongoDB indexing for fast queries

For larger scale:
- Add database sharding
- Implement result caching
- Consider Redis for embeddings cache
- Load balance multiple backend instances

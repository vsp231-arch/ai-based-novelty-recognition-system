import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useEffect } from 'react'
import axios from 'axios'

import AppLayout from './components/Layout/AppLayout'
import Dashboard from './pages/Dashboard'
import AnalyzeText from './pages/AnalyzeText'
import UploadPDF from './pages/UploadPDF'
import DocumentLibrary from './pages/DocumentLibrary'
import Statistics from './pages/Statistics'
import Settings from './pages/Settings'
import NotFound from './pages/NotFound'

function App() {
  useEffect(() => {
    const checkHealth = async () => {
      try {
        await axios.get('/api/health')
      } catch (error) {
        console.error('Backend not available')
      }
    }
    checkHealth()
  }, [])

  return (
    <Router>
      <AppLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/analyze" element={<AnalyzeText />} />
          <Route path="/upload" element={<UploadPDF />} />
          <Route path="/documents" element={<DocumentLibrary />} />
          <Route path="/statistics" element={<Statistics />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AppLayout>
    </Router>
  )
}

export default App
